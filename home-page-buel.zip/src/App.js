import logo from './logo.svg';
import './App.css';
import Farmer from './components/Farmer';
import {BrowserRouter as Router, Route, Routes} from 'react-router-dom';
import React from 'react';
import Landing from './components/Landing';

function App() {
  return (
    // <Router>
    <div>
        <Landing></Landing>
    </div>
    // </Router>
  );
}

export default App;
