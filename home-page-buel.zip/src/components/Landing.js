import React from "react";

function Landing()
{
    return(
        <div>
        <div role="navigation">
    <div className="p-3 bg-light">
      <div className="container"style={"background-color:#16AF00;"}>
        <div className="row align-items-center">
          <div className="col-lg-3 col-md-3 d-none d-md-block">
            
            <div className="mt-1 text-secondary">
              <h2 style="color: white;">BUEL<i className="fa fa-leaf" style={"font-size:30px;color:white;"}></i></h2>
            </div>
          </div>
          <div className="col-lg-6 col-md-6 text-center">
            <div className="display-6" style={"color: white; font-size: 25px;font-weight: bold;"}>Let's Save the Earth!! &nbsp<i className="fa fa-globe" aria-hidden="true" style="color: white; font-size: 25px;"></i></div>
            {/* <!-- <div className="text-secondary" style="color: white;">One step portal for all...</div> --> */}
          </div>
          <div className="col-lg-3 col-md-3 text-end d-none d-md-block" style={"display: inline;"}>
            <input className="form-control me-2" type="search" placeholder="Search" aria-label="Search" style="width: 200px;display: inline;"/>
            <button className="btn btn-outline-success" type="submit" id="btn" style={"background-color:#ADFF2F;"}>Search</button>
            
          </div>
        </div>
      </div>
    </div>

    <div className="border-bottom border-top" id="subNavContainer">
      <nav className="navbar navbar-expand-md">
        <div className="container-fluid">
          <button className="navbar-toggler mx-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation"><i className="fas fa-bars me-2"></i>
            Menu</button>

          <div className=" collapse navbar-collapse" id="navbarNavDropdown">
            <ul className="navbar-nav mx-auto ">
              <li className="nav-item">
                <a className="nav-link mx-2 active" aria-current="page" href="#" style="color: darkgreen;">News</a>
              </li>
              <li className="nav-item">
                <a className="nav-link mx-2 active" href="#" style="color: darkgreen;">Home</a>
              </li>
              <li className="nav-item">
                <a className="nav-link mx-2 active" href="#" style="color: darkgreen;">Our Offering</a>
              </li>
                <li className="nav-item dropdown">
                <a className="nav-link mx-2 dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false" style={"color: darkgreen; font-weight: bold;"}>
                 Bio-Disel Suppliers
                  
                </a>
                <ul className="dropdown-menu" aria-labelledby="navbarDropdownMenuLink" style={"background-color: #ADFF2F;"}>
                  <li><a className="dropdown-item" href="#">Farmer</a></li>
                  <li><a className="dropdown-item" href="#">Warehouse</a></li>
                  <li><a className="dropdown-item" href="#">Manufacturer</a></li>
                  <li><a className="dropdown-item" href="#">Distributor</a></li>
                </ul>

              </li>
              <li className="nav-item dropdown">
                <a className="nav-link mx-2 dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false" style={"color: darkgreen; font-weight: bold;"}>
                 Policies & Compliences
                  
                </a>
                <ul className="dropdown-menu" aria-labelledby="navbarDropdownMenuLink" style={"background-color: #ADFF2F;"}>
                  <li><a className="dropdown-item" href="#">Farmer</a></li>
                  <li><a className="dropdown-item" href="#">Warehouse</a></li>
                  <li><a className="dropdown-item" href="#">Manufacturer</a></li>
                  <li><a className="dropdown-item" href="#">Distributor</a></li>
                </ul>

              </li>
              <li className="nav-item">
                <a className="nav-link mx-2 active" href="#" style={"color: darkgreen;"}>Tech Support</a>
              </li>
              <li className="nav-item dropdown">
                <a className="nav-link mx-2 dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false" style="color: darkgreen; font-weight: bold;">
                 <i className="fa fa-user-circle" style="color:green;font-size:23px;"></i>

                  Login
                  
                </a>
                <ul className="dropdown-menu" aria-labelledby="navbarDropdownMenuLink" style={"background-color: #ADFF2F;"}>
                  <li><a className="dropdown-item" href="#">Farmer</a></li>
                  <li><a className="dropdown-item" href="#">Warehouse</a></li>
                  <li><a className="dropdown-item" href="#">Manufacturer</a></li>
                  <li><a className="dropdown-item" href="#">Distributor</a></li>
                </ul>

              </li>
            </ul>
          </div>
        </div>
      </nav>
    </div>
</div>
</div>
    );
}

    
export default Landing;